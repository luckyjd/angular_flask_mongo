__author__ = 'huydq17'

# Program to add natural
# numbers upto
# sum = 1+2+3+...+n

# To take input from the user,
# n = int(input("Enter n: "))

n = 10

# initialize sum and counter
sum = 0
i = 1

while i <= n:
    if i == 5:
        i += 1
        continue

    if i == 6:
        pass

    sum += i
    i += 1    # update counter

    if i >= 8:
        break

# print the sum
print "The sum is " + str(sum)