def greet(name):
	"""This function greets to
	the person passed in as
	parameter"""
	print "Hello, " + name + ". Good morning!"

# call greet function	
greet("Paul")

# function greet will return None object
print greet("David")

# get doc of greet function
print "============="
print "This is the doc of greet function:"
print greet.__doc__