# If the number is positive, we print an appropriate message

positive = 3
negative = -1
nums = [positive, negative]
for value in nums:
	if value > 0:
		print "{0} is a positive number.".format(value)
	else:
		print "{0} is a negative number.".format(value)
	
print "End."