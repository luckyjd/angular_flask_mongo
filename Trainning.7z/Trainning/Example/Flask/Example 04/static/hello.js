/**
 * Created by huydq17 on 12/5/17.
 */

function sayHello() {
    alert("Hello World")
}
